package cuc.waimai.Dao;

public class UserShop {
    private Integer userShopId;

    private Integer userId;

    private Integer shopId;

    public Integer getUserShopId() {
        return userShopId;
    }

    public void setUserShopId(Integer userShopId) {
        this.userShopId = userShopId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }
}