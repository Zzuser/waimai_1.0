package cuc.waimai.Dao;

public class HorsemanEvaluate {
    private Integer evId;

    private Float evAll;

    private Integer onTimeCount;

    private Integer outTimeCount;

    private Float onTimeRate;

    public Integer getEvId() {
        return evId;
    }

    public void setEvId(Integer evId) {
        this.evId = evId;
    }

    public Float getEvAll() {
        return evAll;
    }

    public void setEvAll(Float evAll) {
        this.evAll = evAll;
    }

    public Integer getOnTimeCount() {
        return onTimeCount;
    }

    public void setOnTimeCount(Integer onTimeCount) {
        this.onTimeCount = onTimeCount;
    }

    public Integer getOutTimeCount() {
        return outTimeCount;
    }

    public void setOutTimeCount(Integer outTimeCount) {
        this.outTimeCount = outTimeCount;
    }

    public Float getOnTimeRate() {
        return onTimeRate;
    }

    public void setOnTimeRate(Float onTimeRate) {
        this.onTimeRate = onTimeRate;
    }
}