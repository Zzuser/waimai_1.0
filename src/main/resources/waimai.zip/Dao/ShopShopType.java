package cuc.waimai.Dao;

public class ShopShopType {
    private Integer shopShoptypeId;

    private Integer shopId;

    private Integer shoptypeId;

    public Integer getShopShoptypeId() {
        return shopShoptypeId;
    }

    public void setShopShoptypeId(Integer shopShoptypeId) {
        this.shopShoptypeId = shopShoptypeId;
    }

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }

    public Integer getShoptypeId() {
        return shoptypeId;
    }

    public void setShoptypeId(Integer shoptypeId) {
        this.shoptypeId = shoptypeId;
    }
}